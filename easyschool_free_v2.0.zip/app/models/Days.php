<?php

class Days extends Eloquent {
	
	protected $guarded = ['id', 'created_at'];

	protected $table = 'days';

}