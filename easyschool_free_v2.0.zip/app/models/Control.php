<?php

class Control extends Eloquent {
	
	protected $table = 'control';
	
	protected $guarded = ['id'];

}