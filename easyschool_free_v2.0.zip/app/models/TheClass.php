<?php

class TheClass extends Eloquent {

	protected $guarded = ['id', 'created_at'];

	protected $table = 'classes';



	
}