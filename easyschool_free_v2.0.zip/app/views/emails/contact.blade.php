<meta charset="utf-8">
Nom : {{ $name }} <br>
Email : {{ $email }} <br>
Date : {{ $date }} <br><br>

<p>{{ $textMsg }}</p>

<br><br>